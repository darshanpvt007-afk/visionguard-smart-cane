VisionGuard Smart Cane - project files
Team: S Darshan (25BCE2883), Tanay Agarwal (25BCE2475)

1_Submissions
  VisionGuard_Review1.docx / .pdf  - Review 1 template (fill the yellow fields)
  VisionGuard_Project_Report.docx / .pdf - Final project report (fill the yellow fields)

2_Presentation
  VisionGuard_Presentation.pptx    - 25 slides, speaker notes on every slide

3_Study_Guides
  VisionGuard_Complete_Guide.pdf   - A-Z procedure, concepts, code, 70 viva Q&As, cheat sheet
  VisionGuard_Build_Guide.pdf      - Step-by-step build guide
  REVIEW1_PREP.md / PROJECT_REPORT.md - text notes

4_Code
  visionguard.ino                  - current sketch (open in Arduino IDE)
  original/visionguard_original.ino - original sketch, unchanged

5_Diagrams
  block, circuit, data flow graph, state diagram (PNG)

Safety: switch the cane OFF before connecting USB.
