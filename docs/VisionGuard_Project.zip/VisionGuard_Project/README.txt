VisionGuard Smart Cane - project files
Team: S Darshan (25BCE2883), Tanay Agarwal (25BCE2475)
B.Tech CSE, Vellore Institute of Technology, Vellore - BACSE324, Slot E2+TE2
Faculty: Dr. Shabeeb Ahmed  -  Submission: 27 October 2026

1_Submissions
  VisionGuard_Review1.docx / .pdf  - Review 1 template (fill the yellow fields)
  VisionGuard_Project_Report.docx / .pdf - Final project report (fill the yellow fields)

2_Presentation
  VisionGuard_Presentation.pptx    - 25 slides; speaker notes show who speaks and what to say
  VisionGuard_Presentation_Script.pdf - printable script for Darshan and Tanay (~14 min)

3_Study_Guides
  VisionGuard_From_Scratch_Deep_Guide.pdf - START HERE: 14 build stages, each with deep viva questions
  VisionGuard_Complete_Guide.pdf   - A-Z procedure, concepts, code, 70 viva Q&As, cheat sheet
  VisionGuard_Build_Guide.pdf      - Step-by-step build guide
  VisionGuard_Deep_Viva_Questions.pdf - 32 deeper questions: chip architecture, ADC, timing, power
  REVIEW1_PREP.md / PROJECT_REPORT.md - text notes

4_Code
  visionguard.ino                  - current sketch (open in Arduino IDE)
  original/visionguard_original.ino - original sketch, unchanged

5_Diagrams
  block, circuit, data flow graph, state diagram (PNG)

Safety: switch the cane OFF before connecting USB.

6_Photos
  Clean prototype photos used in the presentation
